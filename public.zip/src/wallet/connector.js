import { InjectedConnector } from "@web3-react/injected-connector";
import { WalletConnectConnector } from "@web3-react/walletconnect-connector";

export const injected = new InjectedConnector({
  supportedChainIds: [56, 137, 250],
});

export const bscWalletConnect = new WalletConnectConnector({
  rpc: { 56: "https://bsc-dataseed1.binance.org/" },
  bridge: "https://bridge.walletconnect.org",
  qrcode: true,
  pollingInterval: 12000
});

export const maticWalletConnect = new WalletConnectConnector({
  rpc: { 137: "https://polygon-rpc.com/" },
  bridge: "https://bridge.walletconnect.org",
  qrcode: true,
  pollingInterval: 12000
});

export const ftmWalletConnect = new WalletConnectConnector({
  rpc: { 250: "https://rpcapi.fantom.network/" },
  bridge: "https://bridge.walletconnect.org",
  qrcode: true,
  pollingInterval: 12000
});